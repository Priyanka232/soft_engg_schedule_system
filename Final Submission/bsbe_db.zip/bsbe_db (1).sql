-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 17, 2017 at 03:41 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bsbe_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cust_email` varchar(50) NOT NULL,
  `cust_name` varchar(30) NOT NULL,
  `cust_mobile` bigint(20) NOT NULL,
  `cust_address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cust_email`, `cust_name`, `cust_mobile`, `cust_address`) VALUES
('cse150001036@iiti.ac.in', 'TSRV', 7470849010, '310, Jubilee Cyber Grande Apartments, Madhapur, Hyderabad'),
('thotasrirangavineel@gmail.com', 'TSRV', 7470849010, '310, Jubilee Cyber Grande Apartments, Madhapur, Hyderabad');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `p_no` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `u_code` varchar(20) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`p_no`, `amount`, `u_code`, `status`) VALUES
(1, 1000, '307764631', 0),
(2, 1000, '311135011', 0),
(3, 1000, '314505391', 1),
(4, 1000, '317875771', 1),
(5, 1000, '321246151', 1);

-- --------------------------------------------------------

--
-- Table structure for table `slot`
--

CREATE TABLE `slot` (
  `s_no` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `machine` int(11) NOT NULL,
  `s_time` time NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slot`
--

INSERT INTO `slot` (`s_no`, `email`, `machine`, `s_time`, `date`) VALUES
(1, 'thotasrirangavineel@gmail.com', 1, '15:00:00', '2017-03-18'),
(2, 'thotasrirangavineel@gmail.com', 1, '13:01:00', '2017-03-24'),
(3, 'thotasrirangavineel@gmail.com', 1, '13:01:00', '2017-03-24'),
(4, 'thotasrirangavineel@gmail.com', 1, '16:00:00', '2017-03-18'),
(5, 'thotasrirangavineel@gmail.com', 1, '16:00:00', '2017-03-18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`cust_email`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`p_no`);

--
-- Indexes for table `slot`
--
ALTER TABLE `slot`
  ADD PRIMARY KEY (`s_no`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
